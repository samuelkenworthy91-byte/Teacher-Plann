import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { CalendarRange, ShieldCheck, TriangleAlert } from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { getBundle } from "@/lib/queries";
import { findClashes, weeklyLoad } from "@/lib/engine";
import { pretty, prettyShort, startOfWeek } from "@/lib/dates";
import { EmptyState } from "@/components/ui";
import { PlannerBoard, type PlanVM } from "@/components/planner-board";

export const metadata: Metadata = { title: "Smart Planner" };
export const dynamic = "force-dynamic";

export default async function PlannerPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const { classes, slots, plans, settings, today } = await getBundle(user.id);

  if (classes.length === 0 || slots.length === 0) {
    return (
      <div className="rise mx-auto max-w-xl pt-10">
        <EmptyState
          icon={CalendarRange}
          title="The planner needs two ingredients"
          body="Your classes (with sizes) and your timetable. Once it has both, it will schedule every formative so piles never overlap."
          action={
            <div className="flex gap-2">
              <Link href="/classes" className="btn btn-ghost">
                Classes
              </Link>
              <Link href="/timetable" className="btn btn-pen">
                Timetable
              </Link>
            </div>
          }
        />
      </div>
    );
  }

  const classById = new Map(classes.map((c) => [c.id, c]));
  const live = plans
    .filter((p) => p.status !== "returned")
    .sort((a, b) => a.collectDate.localeCompare(b.collectDate));
  const clashes = findClashes(plans);
  const load = weeklyLoad(plans, today, 6);
  const maxLoad = Math.max(8, ...load.map((w) => w.load));
  const monday = startOfWeek(today);

  const vms: PlanVM[] = live.map((p) => {
    const cls = classById.get(p.classId);
    return {
      id: p.id,
      className: cls?.name ?? "?",
      color: cls?.color ?? "#888",
      title: p.title,
      status: p.status as PlanVM["status"],
      planType: p.planType as PlanVM["planType"],
      collectDate: p.collectDate,
      handbackDate: p.handbackDate,
      collectLabel: pretty(p.collectDate),
      handbackLabel: pretty(p.handbackDate),
      collectPeriod: p.collectPeriod,
      handbackPeriod: p.handbackPeriod,
      dailyRate: p.dailyRate,
      totalBooks: p.totalBooks,
      markedCount: p.markedCount,
      late: p.late,
      locked: p.locked,
      weekKey: startOfWeek(p.collectDate),
      isToday: p.collectDate === today || p.handbackDate === today,
    };
  });

  return (
    <div className="space-y-6">
      <header className="rise">
        <p className="text-[0.72rem] font-bold uppercase tracking-[0.16em] text-pen">The engine</p>
        <h1 className="mt-1 font-display text-3xl font-semibold tracking-tight text-ink">
          Smart planner
        </h1>
        <p className="mt-1 max-w-2xl text-[0.88rem] leading-relaxed text-ink-soft">
          Every class gets a formative every{" "}
          <strong className="text-ink">
            {settings.minLessons}–{settings.maxLessons} lessons
          </strong>
          , never more than <strong className="text-ink">{settings.maxGapDays} days</strong> between
          hand-backs, and windows are staggered so{" "}
          <strong className="text-ink">only one pile</strong> is ever on your desk.
        </p>
      </header>

      {/* Clash banner */}
      {clashes.length === 0 ? (
        <div className="rise flex items-center gap-3 rounded-2xl border border-good/25 bg-good-soft px-5 py-4" style={{ animationDelay: "40ms" }}>
          <ShieldCheck size={20} className="shrink-0 text-good" />
          <p className="text-[0.85rem] font-medium text-good">
            No clashes in the diary — you'll never be marking two classes at once.
          </p>
        </div>
      ) : (
        <div className="rise rounded-2xl border border-warn/30 bg-warn-soft px-5 py-4" style={{ animationDelay: "40ms" }}>
          <p className="flex items-center gap-2 text-[0.85rem] font-bold text-warn">
            <TriangleAlert size={17} /> {clashes.length} overlapping window
            {clashes.length === 1 ? "" : "s"}
          </p>
          <p className="mt-1 text-[0.78rem] text-warn">
            Two piles at once — edit dates below, or regenerate to re-stagger the diary.
          </p>
        </div>
      )}

      {/* Load meter */}
      <section className="card rise p-5" style={{ animationDelay: "80ms" }}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-ink">Workload by week</h2>
          <p className="text-[0.72rem] font-semibold text-ink-faint">expected books / day</p>
        </div>
        <div className="flex items-end gap-3">
          {load.map((w, i) => (
            <div key={w.start} className="flex flex-1 flex-col items-center gap-1.5">
              <p className="font-display text-[0.9rem] font-semibold text-ink">{w.load || ""}</p>
              <div className="flex h-24 w-full items-end overflow-hidden rounded-lg bg-ink/5">
                <div
                  className={`w-full rounded-lg transition-all duration-500 ${w.start === monday ? "bg-pen" : "bg-ink/25"}`}
                  style={{ height: `${Math.max(2, (w.load / maxLoad) * 100)}%` }}
                  title={`${w.load} books/day across ${w.plans} pile(s)`}
                />
              </div>
              <p className={`text-[0.62rem] font-bold uppercase tracking-wide ${w.start === monday ? "text-pen" : "text-ink-faint"}`}>
                {i === 0 ? "This wk" : prettyShort(w.start)}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* The diary */}
      <PlannerBoard plans={vms} today={today} />
    </div>
  );
}
